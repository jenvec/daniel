package co.edu.usa.login;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Reto1LoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(Reto1LoginApplication.class, args);
	}

}
