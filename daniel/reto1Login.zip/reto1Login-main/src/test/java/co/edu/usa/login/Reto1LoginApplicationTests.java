package co.edu.usa.login;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto1LoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
